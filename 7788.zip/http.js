/**公共ajax 封装*/
var Sys = {};
var ua = navigator.userAgent.toLowerCase();
var mober = navigator.userAgent.split(";");
var model = ""; //系统类型
var channel = ""; //获取浏览器类型
var sys_v = ""; //系统版本
var o_share = "other"; //分享到哪里
var s;
(s = ua.match(/msie ([\d.]+)/)) ?
(Sys.ie = s[1]) :
(s = ua.match(/firefox\/([\d.]+)/)) ?
(Sys.firefox = s[1]) :
(s = ua.match(/chrome\/([\d.]+)/)) ?
(Sys.chrome = s[1]) :
(s = ua.match(/opera.([\d.]+)/)) ?
(Sys.opera = s[1]) :
(s = ua.match(/cpu iphone os (.*?) like mac os/)) ?
(Sys.AppleWebKit = s[1].replace(/_/g, ".")) :
(s = ua.match(/version\/([\d.]+).*safari/)) ?
(Sys.safari = s[1]) :
0;
//以下进行测试
if (Sys.ie) channel = "ie_" + Sys.ie;
if (Sys.firefox) channel = "firefox_" + Sys.firefox;
if (Sys.chrome) channel = "chrome_" + Sys.chrome;
if (Sys.opera) channel = "opera_" + Sys.opera;
if (Sys.AppleWebKit) channel = "appleWebKit_" + Sys.AppleWebKit;
if (Sys.safari) channel = "Safari_" + Sys.safari;

console.log(s);
// alert(window.navigator.appVersion)

var OSVision = "1.0";
var u = navigator.userAgent;

var isAndroid = u.indexOf("Android") > -1 || u.indexOf("Linux") > -1; //Android

var isIOS = !!u.match(/\(i[^;]+;( U;)? CPU.+Mac OS X/); //ios终端
if (isAndroid) {
    model = "android";

    var androidArr = navigator.userAgent.split(";");
    for (var i = 0; i < androidArr.length; i++) {
        if (androidArr[i].indexOf("Android") > -1) {
            sys_v = androidArr[i].split("Android")[1];
        }
    }
}

if (isIOS) {
    model = "ios";

    sys_v = navigator.userAgent.split(";")[1].match(/\d+\.\d+/g)[0];
}

var http = {
    // url: "http://test-api.bevol.cn:8080/", //测试
    // url: "http://192.168.1.100:8080/", //闵宇
    // url: 'http://uat-api.bevol.cn/',
    url = 'https://api.bevol.cn/',
    res: "",
    post: function (apiurl, params) {
        // return new Promise(function (resolve) {

        $.ajax({
            url: http.url + apiurl,
            type: "POST",
            headers: {
                model: model, //系统类型
                channel: channel, //获取浏览器类型
                sys_v: sys_v, //系统版本
                o_share: o_share //分享到哪里
            },
            async: false,
            data: params,
            dataType: "json",

            xhrFields: {
                withCredentials: true,
                crossDomain: true
            },
            success: function (result) {
                console.log('执行结束');
                http.res = result

            }
        })

        // });
    }
}