var Sys = {};
var ua = navigator.userAgent.toLowerCase();
var mober = navigator.userAgent.split(";");
var model = ""; //系统类型
var channel = ""; //获取浏览器类型
var sys_v = ""; //系统版本
var o_share = "other"; //分享到哪里
console.log(ua);
var Url = 'https://api.bevol.cn';
// var Url = "http://uat-api.bevol.cn";
// var Url = "http://test-api.bevol.cn:8080";
// var Url = 'http://192.168.1.60:8080'
var s;
(s = ua.match(/msie ([\d.]+)/)) ?
(Sys.ie = s[1]) :
(s = ua.match(/firefox\/([\d.]+)/)) ?
(Sys.firefox = s[1]) :
(s = ua.match(/chrome\/([\d.]+)/)) ?
(Sys.chrome = s[1]) :
(s = ua.match(/opera.([\d.]+)/)) ?
(Sys.opera = s[1]) :
(s = ua.match(/cpu iphone os (.*?) like mac os/)) ?
(Sys.AppleWebKit = s[1].replace(/_/g, ".")) :
(s = ua.match(/version\/([\d.]+).*safari/)) ?
(Sys.safari = s[1]) :
0;
//以下进行测试
if (Sys.ie) channel = "ie_" + Sys.ie;
if (Sys.firefox) channel = "firefox_" + Sys.firefox;
if (Sys.chrome) channel = "chrome_" + Sys.chrome;
if (Sys.opera) channel = "opera_" + Sys.opera;
if (Sys.AppleWebKit) channel = "appleWebKit_" + Sys.AppleWebKit;
if (Sys.safari) channel = "Safari_" + Sys.safari;

console.log(s);
// alert(window.navigator.appVersion)

var OSVision = "1.0";
var u = navigator.userAgent;

var isAndroid = u.indexOf("Android") > -1 || u.indexOf("Linux") > -1; //Android

var isIOS = !!u.match(/\(i[^;]+;( U;)? CPU.+Mac OS X/); //ios终端
if (isAndroid) {
  model = "android";

  var androidArr = navigator.userAgent.split(";");
  for (var i = 0; i < androidArr.length; i++) {
    if (androidArr[i].indexOf("Android") > -1) {
      sys_v = androidArr[i].split("Android")[1];
    }
  }
}

if (isIOS) {
  model = "ios";

  sys_v = navigator.userAgent.split(";")[1].match(/\d+\.\d+/g)[0];
}

var midd = "";

if (location.href.indexOf("&") > -1) {
  var arr = location.href.split("&");
  if (arr[0].indexOf("mid") > -1) {
    var marr = arr[0].split("mid=");
    midd = marr[1];
  }
  if (location.href.indexOf("o_share") > -1) {
    o_share = location.href.split("o_share=")[1];
  }
} else {
  var marr = location.href.split("mid=");
  midd = marr[1];
}

var head = {
  model: model, //系统类型
  channel: channel, //获取浏览器类型
  sys_v: sys_v, //系统版本
  o_share: o_share //分享到哪里
};

$(function () {
  // setTimeout(function () {
  $("body").append(
    '<div class="fade" id="fade"></div> <div class="load"> <img src="image/loading.png" alt=""> </div><div class="noreffer">此页面数据失效了 o(╥﹏╥)o ，请下载美丽修行APP查询产品最新信息叭！' +
    '<div class="gobtn btn2">' +
    '<a style="text-decoration: none;color: #fff;" href="http://istatic.bevol.cn/static/download/init/16">下载美丽修行</a>' +
    "</div></div>"
  );
  // $($('body')[0].firstElementChild).css({

  //     '-webkit-filter': 'blur(5px)',
  //     '-moz-filter': 'blur(5px)',
  //     '-o-filter': 'blur(5px)',
  //     '-ms-filter': 'blur(5px)',
  //     'filter': ' blur(5px)'
  // })

  //  }, 200)
});

function skin(skinstr) {
  var split = skinstr.split("_");
  var strings = [];
  if (split.length == 4) {
    switch (split[0]) {
      case "DZ":
        strings.push("重干");
        break;
      case "DQ":
        strings.push("轻干");
        break;
      case "OQ":
        strings.push("轻油");
        break;
      case "OZ":
        strings.push("重油");
        break;
      default:
        strings.push("未知");
        break;
    }
    switch (split[1]) {
      case "RZ":
        strings.push("重耐");
        break;
      case "RQ":
        strings.push("轻耐");
        break;
      case "SQ":
        strings.push("轻敏");
        break;
      case "SZ":
        strings.push("重敏");
        break;
      default:
        strings.push("未知");
        break;
    }
    switch (split[2]) {
      case "N":
        strings.push("非色素");
        break;
      case "P":
        strings.push("色素");
        break;
      default:
        strings.push("未知");
        break;
    }
    switch (split[3]) {
      case "T":
        strings.push("紧致");
        break;
      case "W":
        strings.push("皱纹");
        break;
      default:
        strings.push("未知");
        break;
    }
  }
  strings = strings.join(" | ");
  return strings;
}

function fmtDate(obj) {
  //时间戳转成日期
  obj = obj * 1000;
  var date = new Date(obj);
  var y = 1900 + date.getYear();
  var m = "0" + (date.getMonth() + 1);
  var d = "0" + date.getDate();
  return (
    y +
    "-" +
    m.substring(m.length - 2, m.length) +
    "-" +
    d.substring(d.length - 2, d.length)
  );
}
//福利社
function xxladd0(m) {
  return m < 10 ? "0" + m : m;
}

function xxl(shijianchuo) {
  //shijianchuo是整数，否则要parseInt转换
  var time = new Date(shijianchuo);
  var y = time.getFullYear();
  var m = time.getMonth() + 1;
  var d = time.getDate();
  var h = time.getHours();
  var mm = time.getMinutes();
  var s = time.getSeconds();
  return (
    xxladd0(m) +
    "月" +
    xxladd0(d) +
    "日" +
    xxladd0(h) +
    ":" +
    xxladd0(mm) +
    ":" +
    xxladd0(s)
  );
}